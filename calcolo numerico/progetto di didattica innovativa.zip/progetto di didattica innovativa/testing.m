clear all
close all
clc

tspan = [0,1];
xspan = [0,0.5];

u0 = @(x) 2*cos(4*pi*x)+sin(20*pi*x);
ul = @(t) 2*cos(4*pi*t)-sin(20*pi*t);

a = 1;
cfl = 0.5;

dt = 5.e-3;
dx = dt*a/cfl;

[xx, tt, uu_lf] = hyper_me(tspan, xspan, u0, ul, 1, cfl, dx, dt);
[xx, tt, uu_lw] = hyper_me(tspan, xspan, u0, ul, 2, cfl, dx, dt);
[xx, tt, uu_up] = hyper_me(tspan, xspan, u0, ul, 3, cfl, dx, dt);
[xx, tt, uu_re]  = hyper_me(tspan, xspan, u0, ul, 4, cfl, dx, dt);

t = tt(5);
figure(1)
uex_t = @(x,t) 2*cos(4*pi*(x-t))+sin(20*pi*(x-t));
hold on
plot(tt, uex_t(xx(10), tt), 'r');
plot(tt, uu_lf(10,:),  'b--');
plot(tt, uu_lw(10,:), 'm--');
plot(tt, uu_up(10,:), 'g--');
legend('esatta','lax freidrich','lax wendroff','upwind')
hold off;
% errore nell'applicare i metodi

t_x = 1:size(tt,2);


err_lf = norm(uu_re(t_x,2)-uu_lf(t_x),2);
err_lw = norm(uu_re(t_x,2)-uu_lw(t_x),2);
err_up = norm(uu_re(t_x,2)-uu_up(t_x),2);

figure(2)
hold on

LABEL = categorical({'err_lf','err_lw','err_up'});
LABEL = reordercats(LABEL ,{'err_lf','err_lw','err_up'});
FUNC=[31.5712 32.2244 31.9780];
ylabel='Errore Grafico';
bar(LABEL,FUNC)
ylim([31 32.5])


%err_lf = norm(uex_t(xx(10), tt)-uu_lf(t_x),2);
%err_lw = norm(uex_t(xx(10), tt)-uu_lw(t_x),2);
%err_up = norm(uex_t(xx(10), tt)-uu_up(t_x),2);
%figure(2)
%hold on
%plot(tt, err_lf,  'b--');
%plot(tt, err_lw, 'm--');
%plot(tt, err_up, 'g--');



