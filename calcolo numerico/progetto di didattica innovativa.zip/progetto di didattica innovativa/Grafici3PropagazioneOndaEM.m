% This program describes a moving 1-D wave
% using the finite difference method
clc
close all;
clear all;
%-------------------------------------------------------------------------%
% Initialization

Nx = 301;       % x-Grids
dx = 1;         % Step size
x(:,1) = (0:Nx-1)*dx; %setta x come un vettore colonna a 1 dimensione e a ogni posto assegna da 0 a nx-1 *dx

mpx = (Nx+1)/2; % Mid point of x axis
                % ( Mid pt of 1 to 101 = 51 here )
                
T = 1001;       % Total number of time steps, sul numero di step ha anche impostato l'input in ingresso
f = 10;         % frequency of source, per comepensare dilatazioni va modifcato
dt = 0.001;     % Time-Step
t(:,1)= (0:T-1)*dt;

v = 301;        % Wave velocity, CFL limita v a 1000. con 1001 CFL non valida diverge.
c = v*(dt/dx);  % CFL condition, cmax=1 quindi se sale si spacca tutto
U = zeros(T,Nx);  % U(x,t) = U(space,time), crea matrice T righe Nx colonne si 0

s1 = floor(T/f);  %floor approssima al intero più vicino ovverp 100
%-------------------------------------------------------------------------%
% Initial condition

U((1:s1),1) = sin(2*pi*f.*t(1:s1)); %prende le prime 100 righe di colonna 1 e a ogni posizoone assegna un valore dei primi 100 del seno
U((1:s1),2) = sin(2*pi*f.*t(1:s1)); %fa lo stesso di prima
%-------------------------------------------------------------------------%

% Finite Difference Scheme
for j = 3:T
    for i = 2:Nx-1
        U1 = 2*U(j-1,i)-U(j-2,i);
        U2 = U(j-1,i-1)-2*U(j-1,i)+U(j-1,i+1);
        U(j,i) = U1 + c*c.*U2;    
    end                   
end
%-------------------------------------------------------------------------%
%<<<<<<<<<<<<<<<<<<<<<<<2ONDA cavo cat7 2010 VF74>>>>>>>>>>>>>>>>>>>>>>>>>%

fq = 7,4;         % frequenza 2 onda.
vq = 223;        % Wave velocity espressa in funzione della prima con VF velocity factor
cq = vq*(dt/dx);  % seconda condizione CFL


Uq = zeros(T,Nx);  % U(x,t) = U(space,time)nuova matrice per i calcoli

s1q = floor(T/fq);  %spazio per i calcoli.
%-------------------------------------------------------------------------%
% Initial condition

Uq((1:s1q),1) = sin(2*pi*fq.*t(1:s1q)); %stesso ingresso di prima
Uq((1:s1q),2) = sin(2*pi*fq.*t(1:s1q)); 
%-------------------------------------------------------------------------%
% Finite Difference Scheme
for j = 3:T
    for i = 2:Nx-1
        U1q = 2*Uq(j-1,i)-Uq(j-2,i); 
        U2q = Uq(j-1,i-1)-2*Uq(j-1,i)+Uq(j-1,i+1);
        Uq(j,i) = U1q + cq*cq.*U2q;    
    end                   
end
%-------------------------------------------------------------------------%

%<<<<<<<<<<<<<<<<<<<3ONDA cavo cat3 telefono VF58,5>>>>>>>>>>>>>>>>>>>>>>>%

fz = 5,58;         % frequenza 2 onda.
vz = 176;        % Wave velocity espressa in funzione della prima con VF velocity factor
cz = vz*(dt/dx);  % seconda condizione CFL


Uz = zeros(T,Nx);  % U(x,t) = U(space,time)nuova matrice per i calcoli

s1z = floor(T/fz);  %spazio per i calcoli.
%-------------------------------------------------------------------------%
% Initial condition

Uz((1:s1z),1) = sin(2*pi*fz.*t(1:s1z)); %stesso ingresso di prima
Uz((1:s1z),2) = sin(2*pi*fz.*t(1:s1z)); 
%-------------------------------------------------------------------------%
% Finite Difference Scheme
for j = 3:T
    for i = 2:Nx-1
        U1z = 2*Uz(j-1,i)-Uz(j-2,i); 
        U2z = Uz(j-1,i-1)-2*Uz(j-1,i)+Uz(j-1,i+1);
        Uz(j,i) = U1z + cz*cz.*U2z;    
    end                   
end
%-------------------------------------------------------------------------%





% Plot the results
%{
plot_times = [50 150 250 310];

for i = 1:4
    
  figure(i)
  k = plot_times(i);
  plot(x,U(k,:),x,Uq(k,:),x,Uq(k,:),'linewidth',2);
  set(gca,'xtick',[0:25:300])       %aggiunge griglia
  set(gca,'ytick',[-1:.2:1])        %aggiunge griglia
  grid on;
  axis([min(x) max(x) -2 2]);
  xlabel('X axis','fontSize',14);
  ylabel('Wave Amplitude','fontSize',14);              
  titlestring = ['TIME STEP = ',num2str(k), ' TIME = ',num2str(t(k)), 'second'];
  title(titlestring ,'fontsize',14);                            
  h=gca; 
  get(h,'FontSize') 
  set(h,'FontSize',14);
  fh = figure(i);
  set(fh, 'color', 'white'); 
end
%}
%-------------------------------------------------------------------------%
% Movie for the travelling wave

for j = 1:T              
  plot(x,U(j,:),x,Uq(j,:),x,Uz(j,:),'linewidth',2);
  grid on;
  set(gca,'xtick',[0:25:300])       %aggiunge griglia
  set(gca,'ytick',[-1:.2:1])        %aggiunge griglia
  
  axis([min(x) max(x) -2 2]);
  xlabel('10^3 Km','fontSize',14);
  ylabel('Ampiezza','fontSize',14);              
  titlestring = [' TIME = ',num2str(t(j)*1000), ' millisecondi'];
  title(titlestring ,'fontsize',14);                            
  h=gca; 
  get(h,'FontSize') 
  set(h,'FontSize',14);
  fh = figure(5);
  set(fh, 'color', 'white'); 
  F=getframe;       
end

movie(F,T,1)
%-------------------------------------------------------------------------%

