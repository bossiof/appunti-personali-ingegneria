function [xx, tt, uu] = hyper(tspan, xspan, u0, ul, scheme, cfl, dx, dt)
  % funzione per risolvere le equazioni iperboliche di primo grado omogenee
  % tspan  - estremi intervallo temporale
  % xspan  - estremi intervallo spaziale
  % u0     - function handle condizione iniziale
  % ul     - function handle condizione al bordo
  % scheme - scelta del metodo esplicito
  % cfl    - parametro da rispettare per la stabilità
  % dx     - passo spaziale
  % dt     - passo temporale
  % 
  %
  lambda = dt/dx;
  a = cfl*lambda^(-1);
  xx = xspan(1):dx:xspan(2);
  tt = tspan(1):dt:tspan(2);
  uu = zeros(size(xx,2), size(tt,2));
  
  % condizione iniziale al tempo 0
  uu(:,1) = u0(xx);
  uu(1,:) = ul(tt);
  
  if scheme == 1 % Lax Friedrichs   
    for n = 1:size(uu,2)-1
      for j = 2:size(uu,1)-1
        uu(j,n+1) = 0.5*(uu(j+1,n)+uu(j-1,n)) - 0.5*lambda*a*(uu(j+1,n)-uu(j-1,n));
      end
      end
    
  elseif scheme == 2 % Lax Wendroff 
    for n = 1:size(uu,2)-1
      for j = 2:size(uu,1)-1
        uu(j,n+1) = uu(j,n) - 0.5*lambda*a*(uu(j+1,n)-uu(j-1,n)) + 0.5*lambda^2*a^2*(uu(j+1,n)-2*uu(j,n) + uu(j-1,n));
      end
      end 
        
  elseif scheme == 3 % Upwind
    
    for n = 1:size(uu,2)-1
      for j = 2:size(uu,1)-1
        uu(j,n+1) = uu(j,n) - 0.5*lambda*a*(uu(j+1,n)-uu(j-1,n)) + 0.5*lambda*abs(a)*(uu(j+1,n)-2*uu(j,n)+uu(j-1,n));
      end
    end
    
  %elseif scheme == 4 % campionamento reale
    
   % for n = 1:size(uu,2)-1
    %  for j = 2:size(uu,1)-1
     %   uu(j,n) =@(j,t)2*cos(4*pi*j-n)+sin(20*pi*(j-n));
    %  end
   % end
    
end
  
  
  