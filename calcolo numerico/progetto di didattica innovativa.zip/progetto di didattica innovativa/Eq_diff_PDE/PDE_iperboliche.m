
function [x,t,sol]=PDE_iperboliche(t0,M,x0,xN,h,k,v,r,f,l,g1,g2);
%________________________________________________________________________
%
% Funzione PDE_iperboliche
% ____________________
%
% Chiamata:   [x,t,sol]=PDE_iperboliche(t0,M,x0,xN,h,k,v,r,f,l,g1,g2);
%
% Commento:
%
% La funzione 'PDE_iperboliche' utilizza le formule alle differenze finite  
% per approssimare Uxx e Utt e calcolare la soluzione del seguente problema:
%
% Utt(x,t) - v^2 Uxx(x,t) = r(x,t)    x0<x<xN  ,  t>t0
% U(x,t0)=f(x)                        x0=<x<=xN
% Ut(x,t0)=l(x)                       x0=<x<=xN 
% U(x0,t)=g1(t)                       t>=t0
% U(xN,t)=g2(t)                       t>=t0
%
% dove: 
% U(x,t) e' la funzione incognita, r(x,t) e' il termine noto, f(x), l(x), 
% g1(t) e g2(t) sono funzioni assegnate per i dati iniziali ed al contorno.
%                                                                       
% NB: per la stabilit� deve essere alfa=v*k/h<=1.
%     Si suppone, inoltre, f(x0)=g1(t0) e f(xN)=g2(t0), cio� la 
%     continuit� della soluzione in (x0,t0) e (xN,t0).
%
%________________________________________________________________________
% 
%
% Parametri di input della function:
%
% t0         valore iniziale del tempo; 
% M          numero di livelli richiesti sull'asse dei tempi;
% x0,xN      estremi dell'intervallo [x0,xN] spaziale di integrazione;         
% h          passo di discretizzazione sull'asse x, ossia ampiezza 
%            dei sottointervalli in cui e' stato suddiviso [x0,xN]; 
% k          passo di discretizzazione sull'asse dei tempi da scegliersi 
%            in modo che sia verificata la condizione di stabilit�; 
% v          costante positiva;
% r          stringa contenente l' espressione della funzione r(x,t), che
%            rappresenta il termine noto.
% f,l        stringhe contenenti le espressioni delle funzioni f(x), l(x),
%            che rappresentano le condizioni iniziali;
% g1,g2      stringhe contenenti le espressioni delle funzioni g1(t), g2(t),
%            che rappresentano le condizioni al bordo.
%
% Parametri di output della function:
%
% x          vettore colonna di dimensione N+1 contenente i nodi x0,x1,...,xN;
% t          vettore colonna di dimensione M+1 contenente i nodi t0,t1,...,tM;
% sol        matrice in cui l'elemento sol(i,j) corrisponde all'approssimazione
%            della soluzione nel nodo (x(j-1),t(i-1)), i=1,...,N+1, j=1,...,M+1.
%_________________________________________________________________________
%
% 1� esempio  di utilizzo della function  applicata al seguente 
% problema:
%
% Utt=Uxx                   0<x<1,    t>0
% U(x,0)=sin(pi*x)          0=<x<=1
% Ut(x,0)=0                 0=<x<=1
% U(x0,t)=0                 t>=0
% U(xN,t)=0                 t>=0
%
%
% con soluzione vera:
% U(x,t)=cos(pi*t)*sin(pi*x);
%________________________________________________________________________
%
% clc
% clear all
%
% t0=0;
% M=10;
% x0=0; xN=1;
% h=.05; k=.05;
% v=1;
% r='0';
% f='sin(pi*x)'; 
% l='0';      
% g1='0';  
% g2='0';
% 
% % Implementazione del metodo
% 
%  [x,t,sol]=PDE_iperboliche(t0,M,x0,xN,h,k,v,r,f,l,g1,g2);
%
% % Confronto con la soluzione vera
%
%  [X,T] = meshgrid(x,t);
%  Uvera='cos(pi*T).*sin(pi*X)';
%  Uvera=eval(Uvera);
%  err=abs(Uvera-sol);
%________________________________________________________________________
%
% 2� esempio  di utilizzo della function  applicata al seguente 
% problema:
%
% Utt-4Uxx = exp(-t)(x.^2-24)x                   0<x<1,  t>0
% U(x,0)=x^3                                     0=<x<=1
% Ut(x,0)=-x^3                                   0=<x<=1
% U(x0,t)=0                                      t>=0
% U(xN,t)=exp(-t)                                t>=0
%
%
% con soluzione vera:
% U(x,t)=exp(-t)x^3;
%________________________________________________________________________
%
% clear all; clc
% t0=0;
% M=10;
% x0=0;xN=1;
% h=.05;
% v=2;k=h/v;
% r='x.*exp(-t).*(x.^2-24)';
% f='x.^3';  
% l='-x.^3';
% g1='0';  
% g2='exp(-t)';
% 
% % Implementazione del metodo
% 
% [x,t,sol]=PDE_iperboliche(t0,M,x0,xN,h,k,v,r,f,l,g1,g2);
% 
% % Confronto con la soluzione vera
% 
%  [X,T] = meshgrid(x,t);
%  Uvera=X.^3.*exp(-T); 
%  err=abs(Uvera-sol);
% 
%________________________________________________________________________



alfa=v*k/h;
x=(x0:h:xN)'; x(end)=xN; N=length(x)-1;

f=eval(f).*ones(size(x));  %condizione iniziale U(x,t0) nei nodi (x0 ... xN)
U0=f(2:N);                 %condizione iniziale U(x,t0) nei nodi (x1 ... xN-1)
vv=eval(l).*ones(size(x)); %condizione iniziale Ut(x,t0) nei nodi (x0 ... xN)

% Calcolo della soluzione al passo 1 mediante la discretizzazione della
% condizione al contorno Ut(x,t0) nei nodi (x1 ... xN-1)

t=t0;x=x(2:end-1); tnoto=eval(r).*ones(size(x));
U1=alfa^2/2*(f(1:N-1)+f(1+2:N+1))+(1-alfa^2)*f(2:N)+k*vv(2:N) + 0.5*k^2*tnoto;

tM=k*M+t0;
t=linspace(t0,tM,M+1)';
v1=eval(g1).*ones(size(t)); %condizione al contorno U(xo,t)
v2=eval(g2).*ones(size(t)); %condizione al contorno U(xN,t)

Vj=zeros(N-1,1);
sol=[f'; [v1(2) U1' v2(2)]];
Uj=U1;
Uj_1=U0;
T=2*eye(N-1)-diag(ones(1,N-2),-1)-diag(ones(1,N-2),+1);
A=2*eye(N-1)-alfa^2*T;

t=t(2);
for j=2:M      
    Vj([1,N-1])=[v1(j),v2(j)];
    tnoto=eval(r).*ones(size(x));
    Uj1=A*Uj-Uj_1+alfa^2*Vj + k^2*tnoto;  
    sol=[sol;[v1(j+1); Uj1 ;v2(j+1)]'];
    Uj_1=Uj;
    Uj=Uj1;    
    t=t+k;
end
t=linspace(t0,tM,M+1)';
x=[x0;x;xN];
