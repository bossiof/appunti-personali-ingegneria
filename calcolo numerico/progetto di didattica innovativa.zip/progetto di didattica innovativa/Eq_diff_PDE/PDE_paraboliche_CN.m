
function [x,t,sol]=PDE_paraboliche_CN(t0,M,x0,xN,h,k,c,r,f,g,l);
%________________________________________________________________________
%
% Funzione PDE_paraboliche_CN
% ____________________
%
% Chiamata:   [x,t,sol]=PDE_paraboliche_CN(t0,M,x0,xN,h,k,c,r,f,g,l);
%
% Commento:
%
% La funzione 'PDE_paraboliche_CN' utilizza il metodo di Crank-Nicolson 
% per il calcolo della soluzione del seguente problema di Dirichlet:
%
% Ut(x,t) - c Uxx(x,t) = r(x,t)      x0<x<xN,  t>t0, c>0
% U(x,t0)=f(x)                       x0=<x<=xN
% U(x0,t)=g(t)                       t>=t0
% U(xN,t)=l(t)                       t>=t0
%
% dove: 
% U(x,t) � la funzione incognita, r(x,t) e' il termine noto, f(x), g(t) e 
% l(t) sono funzioni assegnate per i dati iniziali ed al contorno.
%                                                                    
% NB: Si suppone f(x0)=g(t0) e f(xN)=l(t0), cio� la continuit� della 
%     soluzione in (x0,t0) e (xN,t0).
%________________________________________________________________________
% 
%
% Parametri di input della function:
%
% t0         valore iniziale del tempo; 
% M          numero di livelli richiesti sull'asse dei tempi;
% x0,xN      estremi dell'intervallo [x0,xN] spaziale di integrazione;         
% h          passo di discretizzazione sull'asse x, ossia ampiezza 
%            dei sottointervalli in cui e' stato suddiviso [x0,xN]; 
% k          passo di discretizzazione sull'asse dei tempi; 
% c          costante positiva;
% r          stringa contenente l'espressione della funzione r(x,t), che 
%            rappresenta il termine noto;
% f          stringa contenente l'espressione della funzione f(x), che 
%            rappresenta la condizione iniziale;
% g,l        stringhe contenenti le espressioni delle funzioni g(t), l(t),
%            che rappresentano le condizioni al bordo.
%
% Parametri di output della function:
%
% x          vettore colonna di dimensione N+1 contenente i nodi x0,x1,...,xN;
% t          vettore colonna di dimensione M+1 contenente i nodi t0,t1,...,tM;
% sol        matrice in cui l'elemento sol(i,j) corrisponde all'approssimazione
%            della soluzione nel nodo (x(j-1),t(i-1)), i=1,...,N+1, j=1,...,M+1.
%_________________________________________________________________________
%
% 1� esempio  di utilizzo della function  applicata al seguente 
% problema:
%
% Ut=Uxx                 0<x<10,  t>0
% U(x,0)=sin(pi/10*x)    0=<x<=10
% U(0,t)=0               t>=0
% U(10,t)=0              t>=0
%
%
% con soluzione vera:
% U(x,t)=sin(pi/10*x)*exp(-(pi/10)^2*t);
%_________________________________________________________________________
%
% clear all; clc
% t0=0;
% M=10;
% x0=0;xN=10;
% h=.25; k=0.03;
% c=1;
% r='0';
% f='sin(pi/10*x)'; 
% g='0';  
% l='0';
% 
% % Implementazione del metodo
% 
% [x,t,sol]=PDE_paraboliche_CN(t0,M,x0,xN,h,k,c,r,f,g,l);
%
% % Confronto con la soluzione vera
%
%  [X,T] = meshgrid(x,t);
%  Uvera='sin(pi/10*X).*exp(-(pi/10)^2*T)';
%  Uvera=eval(Uvera);
%  err=abs(Uvera-sol);
%_________________________________________________________________________
%
% 2� esempio  di utilizzo della function  applicata al seguente 
% problema:
%
% Ut-1/2Uxx=-3(1+x)      0<x<2,    t>0
% U(x,0)=x.^3            0=<x<=2
% U(0,t)=-3t             t>=0
% U(2,t)=8-3t            t>=0
%
%
% con soluzione vera:
% U(x,t)=x^3-3t;
%_________________________________________________________________________
%
% clc
% clear all
% t0=0;M=20;
% x0=0;xN=2;
% h=0.1; k=0.01;
% c=1/2;
% 
% r='-3*(1+x)';
% f='x.^3';
% g='-3*t';
% l='8-3*t';
% 
% % Implementazione del metodo
%
% [x,t,sol]=PDE_paraboliche_CN(t0,M,x0,xN,h,k,c,r,f,g,l);
%
% % Confronto con la soluzione vera
%
% [X,T]=meshgrid(x,t); 
% Uvera=X.^3-3*T;
% err=abs(Uvera-sol);
%
%_________________________________________________________________________
%


alfa=k*c/h^2;
x=(x0:h:xN)'; x(end)=xN; N=length(x)-1; 
tM=M*k+t0; t=linspace(t0,tM,M+1)';

f=eval(f).*ones(size(x));  %condizione iniziale U(x,0) 
v1=eval(g).*ones(size(t)); %condizione al contorno U(xo,t)
v2=eval(l).*ones(size(t)); %condizione al contorno U(xN,t)

U0=f(2:N);                 
sol=f';
Vj=zeros(N-1,1);
Uj=U0;
bb=alfa*ones(N-2,1);
A=-diag(bb,-1)+2*(1+alfa)*eye(N-1)-diag(bb,1);
B= diag(bb,-1)+2*(1-alfa)*eye(N-1)+diag(bb,1);

t=t0+k/2;x=x(2:end-1);
for j=1:M      
    tnoto=eval(r).*ones(N-1,1);
    Vj([1,N-1])=[v1(j)+v1(j+1),v2(j)+v2(j+1)];
    b=B*Uj+alfa*Vj + 2*k*tnoto;
    Uj1=A\b;
    sol=[sol;[v1(j+1); Uj1 ;v2(j+1)]'];
    Uj=Uj1;
    t=t+k;
end
t=linspace(t0,tM,M+1)'; 
x=[x0;x;xN];

