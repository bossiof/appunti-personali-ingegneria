
function [x,t,sol]=PDE_paraboliche_CN1(t0,M,x0,xN,h,k,c,r,f,g,l);
%________________________________________________________________________
%
% Funzione PDE_paraboliche_CN1
% ____________________
%
% Chiamata:   [x,t,sol]=PDE_paraboliche_CN1(t0,M,x0,xN,h,k,c,r,f,g,l);
%
%
% Commento:
%
% La funzione 'PDE_paraboliche_CN1' utilizza il metodo di Crank-Nicolson 
% per il calcolo della soluzione del seguente problema misto 
% Dirichlet-Neumann:
%
% Ut(x,t) - c Uxx(x,t) = r(x,t)      x0<x<xN ,   t>t0,   c>0
% U(x,t0)=f(x)                       x0=<x<=xN
% U(x0,t)=g(t)                       t>=t0
% Ux(xN,t)=l(t)                      t>=t0
%
% dove: 
% U(x,t) � la funzione incognita, r(x,t) e' il termine noto, f(x), g(t) e 
% l(t) sono funzioni assegnate per i dati iniziali ed al contorno.
%
% NB: Si fa notare che la condizione in xN � assegnata sulla derivata prima 
%     rispetto a x, che viene approssimata con una differenza centrale.
%                                                                    
%________________________________________________________________________
% 
%
% Parametri di input della function:
%
% t0         valore iniziale del tempo; 
% M          numero di sottointervalli in cui e' stato suddiviso [t0,tM];
% x0,xN      estremi dell'intervallo [x0,xN] spaziale di integrazione;         
% h          passo di discretizzazione sull'asse x, ossia ampiezza 
%            dei sottointervalli in cui e' stato suddiviso [x0,xN]; 
% k          passo di discretizzazione sull'asse dei tempi; 
% c          costante positiva;
% r          stringa contenente l'espressione della funzione r(x,t), che 
%            rappresenta il termine noto;
% f          stringa contenente l'espressione della funzione f(x), che 
%            rappresenta la condizione iniziale;
% g,l        stringhe contenenti le espressioni delle funzioni g(t), l(t),
%            che rappresentano le condizioni al bordo.
%
% Parametri di output della function:
%
% x          vettore colonna di dimensione N+1 contenente i nodi x0,x1,...,xN;
% t          vettore colonna di dimensione M+1 contenente i nodi t0,t1,...,tM;
% sol        matrice in cui l'elemento sol(i,j) corrisponde all'approssimazione
%            della soluzione nel nodo (x(j-1),t(i-1)), i=1,...,N+1, j=1,...,M+1.
%_________________________________________________________________________
%
% 1� esempio  di utilizzo della function  applicata al seguente 
% problema:
%
% Ut=Uxx                                0<x<10  t>0
% U(x,t0)=sin(pi/10*x)                  0=<x<=10
% U(0,t)=0                              t>=0
% Ux(10,t)=-(pi/10).*exp(-(pi/10)^2*t)  t>=0
%
% con soluzione vera:
% U(x,t)=sin(pi/10*x)*exp(-(pi/10)^2*t);
%_________________________________________________________________________
%
% clear all; clc
% x0=0; xN=10;
% t0=0; M=10;
% h=.5; k=.2;
% c=1;
% r='0';
% f='sin(pi/10*x)';  
% g='0';
% l='-(pi/10).*exp(-(pi/10)^2*t)';
% 
% %  Implementazione del metodo
%  
% [x,t,sol]=PDE_paraboliche_CN1(t0,M,x0,xN,h,k,c,r,f,g,l);
% 
% % Confronto con la soluzione vera
% 
% [X,T] = meshgrid(x,t);
% Uvera='sin(pi/10*X).*exp(-(pi/10)^2*T)';
% Uvera=eval(Uvera);
% err=abs(Uvera-sol);
%_________________________________________________________________________
%
% 2� esempio  di utilizzo della function  applicata al seguente 
% problema:
%
% Ut-1/2Uxx=-exp(-t)(1+x^2)      0<x<2,    t>0
% U(x,0)=x.^2                    0=<x<=2
% U(0,t)=0                       t>=0
% Ux(2,t)=4exp(-t)               t>=0
%
%
% con soluzione vera:
% U(x,t)=exp(-t)x^2;
%_________________________________________________________________________
%
% clc
% clear all
% t0=0;M=20;
% x0=0;xN=2;
% h=0.1; k=0.01;
% c=1/2;
% 
% r='-exp(-t).*(x.^2+1)';
% f='x.^2';
% g='0';
% l='4*exp(-t)';
% 
% % Implementazione del metodo
% 
% [x,t,sol]=PDE_paraboliche_CN1(t0,M,x0,xN,h,k,c,r,f,g,l);
% 
% % Confronto con la soluzione vera
% 
% [X,T]=meshgrid(x,t); 
% Uvera=X.^2.*exp(-T);
% err=abs(Uvera-sol);
%_________________________________________________________________________
%



alfa=k*c/h^2;
x=(x0:h:xN)'; x(end)=xN; N=length(x)-1; 
tM=k*M+t0; t=linspace(t0,tM,M+1)';

if N<=2 
    disp(' Per effettuare il calcolo � necessario diminuire h')
    x=[];t=[];sol=[];
    return
end

f=eval(f).*ones(size(x));    %condizione iniziale U(x,0) 
v1=eval(g).*ones(size(t));   %condizione al contorno U(xo,t)
v2=eval(l).*ones(size(t));   %condizione al contorno Ux(xN,t)

U0=f(2:N+1);                 
sol=f';
Uj=U0;
Vj=zeros(N,1);
bb=alfa*ones(N-1,1);
A=-diag(bb,-1)+2*(1+alfa)*eye(N)-diag(bb,1); A(N,N-1)=-2*alfa;
B= diag(bb,-1)+2*(1-alfa)*eye(N)+diag(bb,1); B(N,N-1)= 2*alfa;

t=t0+k/2;x=x(2:end);
for j=1:M      
    tnoto=eval(r).*ones(N,1);
    Vj([1,N])=[v1(j)+v1(j+1),2*h*(v2(j)+v2(j+1))];
    b=B*Uj+alfa*Vj +2*k*tnoto;
    Uj1=A\b;
    sol=[sol;[v1(j+1); Uj1]'];
    Uj=Uj1;
    t=t+k;
end
t=linspace(t0,tM,M+1)';
x=[x0;x];
