
function [x,t,sol]=PDE_upwind(t0,M,x0,xN,h,k,c,r,f,g);
%________________________________________________________________________
%
% Funzione PDE_upwind
% ____________________
%
% Chiamata:   [x,t,sol]=PDE_upwind(t0,M,x0,xN,h,k,c,r,f,g);
%
% Commento:
%
% La funzione 'PDE_upwind' utilizza il metodo upwind, ottenuto 
% approssimando Ux e Ut con le rispettive differenze finite all'indietro 
% e in avanti, per il calcolo della soluzione del seguente problema a 
% coefficienti variabili:
%
% Ut(x,t) + c(x,t)*Ux(x,t) = r(x,t)    x0<x<=xN,  t>t0, c(x,t)>0
% U(x,t0)=f(x)                         x0<=x<=xN
% U(x0,t)=g(t)                         t>=t0
%
% dove: 
% U(x,t) � la funzione incognita, r(x,t) e' il termine noto, f(x) e g(t) 
% sono funzioni assegnate per i dati iniziali ed al contorno.
%     
% NB: per la stabilit� del metodo, deve essere alpha(x,t)=c(x,t)*k/h<=1.
%     Si suppone, inoltre, f(x0)=g(t0), cio� la continuit� della 
%     soluzione in (x0,t0).
%
%________________________________________________________________________
% 
%
% Parametri di input della function:
%
% t0         valore iniziale del tempo; 
% M          numero di livelli richiesti sull'asse dei tempi;
% x0,xN      estremi dell'intervallo [x0,xN] spaziale di integrazione;         
% h          passo di discretizzazione sull'asse x, ossia ampiezza 
%            dei sottointervalli in cui e' stato suddiviso [x0,xN]; 
% k          passo di discretizzazione sull'asse dei tempi da scegliersi 
%            in modo che sia verificata la condizione di stabilit�; 
% c          stringa contenente l'espressione del coefficiente variabile 
%            c(x,t);
% r          stringa contenente l'espressione del termine noto r(x,t);
% f,g        stringhe contenenti le espressioni delle funzioni f(x), g(t),
%            che rappresentano le condizioni iniziali e al contorno.
%
% Parametri di output della function:
%
% x          vettore colonna di dimensione N+1 contenente i nodi x0,x1,...,xN;
% t          vettore colonna di dimensione M+1 contenente i nodi t0,t1,...,tM;
% sol        matrice in cui l'elemento sol(i,j) corrisponde all'approssimazione
%            della soluzione nel nodo (x(j-1),t(i-1)), i=1,...,N+1, j=1,...,M+1.
%_________________________________________________________________________
%
% 1� esempio  di utilizzo della function  applicata al seguente 
% problema:
%
%  Ut+2t*Ux=0          0<x<=xN, con xN dato in input,  t>0   
%  U(x,0)=1/(1+x^2)    0<=x<=xN
%  U(0,t)=1/(1+t^4)    t>=0
%
% con soluzione vera:
% U(x,t)=1/(1+(x-t^2)^2);
%________________________________________________________________________
%
% clear all; clc
% t0=0;
% M=10;
% x0=0;xN=3;
% h=.2;
% k=.0125;
% c='2*t';
% r='0';
% f='1./(1+x.^2)';  % condizione iniziale U(x,t0)
% g='1./(1+t.^4)';  % condizione al contorno U(x0,t)
% 
% % Implementazione del metodo
% 
% [x,t,sol]=PDE_upwind(t0,M,x0,xN,h,k,c,r,f,g);
%
% % Confronto con la soluzione vera
%
%  [X,T] = meshgrid(x,t);
%  Uvera=1./(1+(X-T.^2).^2); 
%  err=abs(Uvera-sol);
%  
%________________________________________________________________________
%
% 2� esempio  di utilizzo della function  applicata al seguente 
% problema:
%
%  Ut+(t^2+x)Ux=exp(-t)(x+2t^2)x     0<x<=xN, con xN dato in input,  t>0   
%  U(x,0)=x^2    0<=x<=xN
%  U(0,t)=0      t>=0
%
% con soluzione vera:
% U(x,t)=exp(-t)x^2;
%_______________________________________________________________________
%
% clear all; clc
% t0=0;
% M=10;
% x0=0;xN=4;
% h=.1;
% k=.01;
% c='t.^2+x';
% r='exp(-t).*(2*t.^2+x).*x';
% f='x.^2';      % condizione iniziale U(x,t0)
% g='0';         % condizione al contorno U(x0,t)
% 
% % Implementazione del metodo
% 
% [x,t,sol]=PDE_upwind(t0,M,x0,xN,h,k,c,r,f,g);
% 
% % Confronto con la soluzione vera
% 
%  [X,T] = meshgrid(x,t);
%  Uvera=X.^2.*exp(-T); 
%  err=abs(Uvera-sol);
%
%________________________________________________________________________


x=(x0:h:xN)'; x(end)=xN; N=length(x)-1; 
tM=k*M+t0; t=linspace(t0,tM,M+1)';

U0=eval(f).*ones(N+1,1); %condizione iniziale U(x,t0)
vv=eval(g).*ones(M+1,1); %condizione al contorno U(x0,t)
Vj=zeros(N,1);
sol=U0';
Uj=U0(2:N+1);

t=t0;
x=x(2:end);
for j=1:M
    alpha=(eval(c)*k/h).*ones(N,1); 
    tnoto=eval(r).*ones(N,1);
    A=diag(1-alpha)+diag(alpha(2:end),-1);
    Vj(1)=vv(j);
    Uj1=A*Uj+alpha(1)*Vj +k*tnoto;
    sol=[sol;[vv(j+1); Uj1]'];
    Uj=Uj1;
    t=t+k;
end
t=linspace(t0,tM,M+1)';
x=[x0;x];
