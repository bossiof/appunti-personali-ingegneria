
function [x,y,sol]=PDE_ellittiche(y0,yM,x0,xN,h,f,r,g1,g2,g3,g4);
%_____________________________________________________________________________
%
% Funzione PDE_ellittiche
% _________________________
%
% Chiamata:   [x,y,sol]=PDE_ellittiche(y0,yM,x0,xN,h,f,r,g1,g2,g3,g4);
%
%
% Commento:
%
% La funzione 'PDE_ellittiche' utilizza le formule alle differenze finite 
% per approssimare Uxx e Uyy, e calcolare la soluzione del seguente problema:
%
% - Uyy - Uxx = F(x,y,U)    x0<x<xN, y0<y<yM 
%
%          /   g1(x)        x0<=x<=xN, y=y0     
% U(x,y)= /    g2(y)        y0<=y<=yM, x=xN    
%         \    g3(x)        x0<=x<=xN, y=yM    
%          \   g4(y)        y0<=y<=yM, x=x0    
%
% dove: 
% U(x,y) � la funzione incognita, F(x,y,U) � il termine noto, che viene 
% preso della forma: F(x,y,U)=r(x,y)*U(x,y)+f(x,y), mentre g1(x), g2(y), 
% g3(x) e g4(y) sono le condizioni assegnate sul bordo.
%                                                                    
% NB: nel programma k � posto pari a h. Si suppone inoltre che la regione 
%     in cui il problema e' definito, sia rettangolare.
%_____________________________________________________________________________
% 
%
% Parametri di input della function:
%
% y0,yM  estremi dell'intervallo [y0,yM] spaziale di integrazione;         
% x0,xN  estremi dell'intervallo [x0,xN] spaziale di integrazione;         
% h      passo di discretizzazione sull'asse x, ossia ampiezza dei sottointervalli
%        in cui e' stato suddiviso [x0,xN]; esso coincide con la suddivisione
%        di [y0,yM];
% f      stringa contenente l'espressione della funzione f(x,y);
% r      stringa contenente l'espressione della funzione r(x,y);
% g1     stringa contenente l'espressione della funzione g1(x), che rappresenta 
%        le condizioni assegnate al bordo inferiore del rettangolo;
% g2,g4  stringhe contenenti l'espressione delle funzioni g2(y) e g4(y), che  
%        rappresentano le condizioni rispettivamente ai bordi destro e sinistro 
%        del rettangolo;
% g3     stringa contenente l'espressione della funzione g3(x), che rappresenta 
%        le condizioni assegnate al bordo superiore del rettangolo.
%
% Parametri di output della function:
%
% x      vettore colonna di dimensione N+1 contenente i nodi x0,x1,...,xN;
% y      vettore colonna di dimensione M+1 contenente i nodi y0,y1,...,yM;
% sol    matrice in cui l'elemento sol(i,j) corrisponde all'approssimazione
%        della soluzione nel nodo (x(j-1),y(i-1)), i=1,...,N+1, j=1,...,M+1.
%_____________________________________________________________________________
%
% 1� esempio  di utilizzo della function  applicata al seguente problema: 
%
% Uyy+Uxx=0                   0<x<3  0<y<4
% U(x,y)=(x-1)^2-(y-2)^2      sui lati del rettangolo di vertici:
%                             (0,0), (3,0), (3,4), (0,4)
%                                                           
% con soluzione vera:
% U(x,y)=(x-1)^2-(y-2)^2;
%_____________________________________________________________________________
%
% clear all; clc
% x0=0; xN=3;
% y0=0; yM=4;
% h=0.2;
% f='0';
% r='0';
% g1='(x-1).^2-4';
% g2='4-(y-2).^2';
% g3='(x-1).^2-4';
% g4='1-(y-2).^2';
% Uvera='(X-1).^2-(Y-2).^2';
% 
% % Implementazione del metodo
% 
% [x,y,sol]=PDE_ellittiche(y0,yM,x0,xN,h,f,r,g1,g2,g3,g4);
%
% % Confronto con la soluzione vera
%
% [X,Y]=meshgrid(x,y);
% Uvera=eval(Uvera);
% err=abs(Uvera-sol);
%
%_____________________________________________________________________________
%
% 2� esempio  di utilizzo della function  applicata al seguente problema: 
%
% Uyy+Uxx=2U(x,y)-2*(exp(-(x+y))-(1-y.^2))      0<x<1,  0<y<1
% U(x,y)=x exp(-(y+x)) + y^2                    sui lati del quadrato di 
%                                               vertici:
%                                               (0,0), (1,0), (1,1), (0,1)
%                                                           
% con soluzione vera:
% U(x,y)=x exp(-(y+x)) + y^2;
%
%______________________________________________________________________________
%
%
% clear all; clc
% y0=0; yM=1;
% x0=0; xN=1;
% h=.1;
% 
% r='-2';
% f='2*(exp(-(x+y))-1+y.^2)';
% g1='x.*exp(-x)';
% g2='exp(-(y+1))+y.^2';
% g3='x.*exp(-1-x)+1';
% g4='y.^2';
%
% % Implementazione del metodo
% 
% [x,y,sol]=PDE_ellittiche(y0,yM,x0,xN,h,f,r,g1,g2,g3,g4);
% 
% % Confronto con la soluzione vera
% 
%  [X,Y] = meshgrid(x,y);
%  Uvera=X.*exp(-(Y+X))+Y.^2; 
%  err=abs(Uvera-sol);
%_____________________________________________________________________________



x=(x0:h:xN)'; x(end)=xN; N=length(x)-1;
y=(y0:h:yM)'; y(end)=yM; M=length(y)-1;


f=[f,'+0*x+0*y']; f=inline(f);
r=[r,'+0*x+0*y']; r=inline(r);
g1=[g1,'+0*x']; g1=inline(g1);
g2=[g2,'+0*y']; g2=inline(g2);
g3=[g3,'+0*x']; g3=inline(g3);
g4=[g4,'+0*y']; g4=inline(g4);


% Costruzione della matrice dei coefficienti A

R=[];
for j=1:M-1
    R=[R,feval(r,x(2:N),y(j+1))'];
end

% s � il numero di nodi interni in cui viene calcolata la soluzione

s=(M-1)*(N-1);

% N.B. Le righe commentate possono utilizzarsi in caso di matrici di piccole
%      dimensioni. In caso di grandi dimensioni � conveniente usare la 
%      costruzione mediante il comando spdiags.
%
% A=diag((4-h^2*R))-diag(ones(s-1,1),1)-diag(ones(s-1,1),-1);
% A=A-diag(ones((M-2)*(N-1),1),N-1)-diag(ones((M-2)*(N-1),1),-(N-1));

e = ones(s,1);
A = spdiags([ -e -e (4-h^2*R)' -e  -e], [-(N-1) -1 0 1 N-1] , s, s);

% devono essere azzerati alcuni elementi delle codiagonali principali

for k=N-1:N-1:(M-2)*(N-1)
    A(k,k+1)=0;
    A(k+1,k)=0;
end

% costruzione del vettore termini noti
 
F=[];
for j=1:M-1
    F=[F,feval(f,x(2:N),y(j+1))'];
end

% condizioni al bordo inferiore

G=zeros(1,(N-1)*(M-1));
G(1:N-1)=[feval(g1,x(2:N))'];
G(1)=G(1)+feval(g4,y(2));
G(N-1)=G(N-1)+feval(g2,y(2));

% condizioni ai bordi destro e sinistro

for j=2:M-2
    G((j-1)*(N-1)+1)=feval(g4,y(j+1));
    G(j*(N-1))=feval(g2,y(j+1));
end

% condizioni al bordo superiore

G((M-2)*(N-1)+1:end)=[feval(g3,x(2:N))'];
G((M-2)*(N-1)+1)=G((M-2)*(N-1)+1)+feval(g4,y(M));
G((M-1)*(N-1))=G((M-1)*(N-1))+feval(g2,y(M));

F=h^2*F+G;

% calcolo della soluzione

U=A\F';

%la soluzione trovata viene messa in una matrice 

for j=1:M-1
    sol(j,:)=[feval(g4,y(j+1)) U((j-1)*(N-1)+1:(j)*(N-1))' feval(g2,y(j+1))];
end
sol=[feval(g1,x)';sol;feval(g3,x)' ];
